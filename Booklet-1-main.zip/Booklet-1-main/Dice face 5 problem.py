#Main program
#Dice face 5 problem
def Output():
  print("ooooooooooo")
  print("o         o")
  print("o  #   #  o")
  print("o    #    o")
  print("o  #   #  o")
  print("o         o")
  print("ooooooooooo")
#Subroutine to output text
Output()