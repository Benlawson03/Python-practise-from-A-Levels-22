#Characters problem
def digits(d):
  return(d)

def characters():
  return(c)

c = ("0123456789 ")
d = ("abcdABCD@#!£")
alphanumerics = (c+d)

print (alphanumerics)
