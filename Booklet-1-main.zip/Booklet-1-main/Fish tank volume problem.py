#Fish tank problemn
l = int(input())
h = int(input())
d = int(input())

v = (l * h * d)
print(v/1000)